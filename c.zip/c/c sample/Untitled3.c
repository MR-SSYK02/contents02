#include <stdio.h>
int main()
{
FILE *fp;

fp=fopen("sample.txt","w");
fputc('c',fp);
fputs("hello",fp);
fclose(fp);//close
}
