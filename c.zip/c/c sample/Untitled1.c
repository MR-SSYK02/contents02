#include<stdio.h>
int main(){
FILE *fp;
char c;
fp = fopen("sample.txt","r");
c= getc(fp);
printf("%c",c);
}
