#include <stdio.h>
int main()
{
FILE *fp;
char c[100];

fp=fopen("lsample.txt","a");
fputc('c',fp);
fputs("hello",fp);
fclose(fp);
}
