#include <stdio.h>
int main()
{
FILE *fp;
fp=fopen("sample.txt","a");
fputc('c',fp);
fputs("hello",fp);
fclose(fp);
}
