#include<stdio.h>
int main(){
FILE *fp;
char c[100];
fp = fopen("sample.txt","r");
fgets(c,5,fp);
printf("%s",c);
}
