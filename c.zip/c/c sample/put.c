#include<stdio.h>
int main()
{
    FILE *fp;
    char c[20];
    fp= fopen("sample.txt","w");
    fputc("c",fp);//single character
    fputs("HELLO",fp);//string
    fclose(fp);
}
