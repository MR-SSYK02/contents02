#include<stdio.h>
    void myfun(int num)
    {
    printf("\n num :%d",num);
    }
    int main()
    {
    myfun(25);
    return 0;
    }
