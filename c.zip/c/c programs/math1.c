#include<stdio.h>
#include<math.h>
    int main()
    {
    printf("\n SQRT :%f " ,sqrt(9));
    printf("\n POW :%f " ,pow (2,9));
    printf("\n abs :%f ", abs (25.02));
    return 0;
    }
