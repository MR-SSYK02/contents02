#include<stdio.h>
int factorial(int n);
int main(){
    int num;
    printf("Enter your number= ");
    scanf("%d",&num);

    return 0;
}
    int factorial(int n)
      {
     if(n==0){
     return 1;

     }else{
     return n*factorial(n-1);
          printf("factorial is %d",num);
    return 0;
     }
    }
