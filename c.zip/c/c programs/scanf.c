#include<stdio.h>
#include<conio.h>
int main(){
 int num;
 printf("/nEnter the num: ");
 scanf("%d",&num);
 return 0;
}
