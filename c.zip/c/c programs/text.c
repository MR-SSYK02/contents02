#include<stdio.h>
#include<math.h>
int main(){
printf("\nSORT %f",sqrt(4));
printf("\nFLOOR %f",floor(10.02));
printf("\nABS %d",abs(-15));
return 0;
}
