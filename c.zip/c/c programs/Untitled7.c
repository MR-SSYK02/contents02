#include<stdio.h>
#include<conio.h>
int main()
{
    int num1,num2,sum;
    printf("\nenter number1:");
    scanf("%d",&num1);
    printf("\nenter number2:");
    scanf("%d",&num2);
    sum = num1 + num2;
    printf("%d + %d= %d",num1,num2,sum);
    return 0;

}
