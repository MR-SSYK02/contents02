#include<stdio.h>
#include<string.h>
union book{
    int no;
    float price;
    char author[40];
};
int main()
{
    union book hp;
    hp.no=5;
    hp.price=450.25;
    strcpy(hp.author,"abc" );
    printf("%d\n",hp.no);
    printf("%f\n",hp.price);
    printf("%s",hp.author);
    return 0;

}
