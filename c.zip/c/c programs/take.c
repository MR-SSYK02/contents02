#include<stdio.h>
#include<conio.h>
int main()
{
    int num1,num2;
    printf("\nEnter number 1:");
    scanf("%d",&num1);
    printf("\nEnter number 3:");
    scanf("%d",&num2);
    return 0;
}
