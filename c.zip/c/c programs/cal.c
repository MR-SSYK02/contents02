#include<stdio.h>
#include<stdlib.h>
#include<string.h>
 int main()
{
char *name;
name = calloc(4,1);
name = strcpy(name,"hello");
printf("%s",name);
free(name);
printf("%s",name);
}
