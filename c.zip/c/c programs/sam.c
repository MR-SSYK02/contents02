#include<stdio.h>
#include<conio.h>
int main()
{
    int num;
    printf("enter num : ");
    scanf("%d",num);
    return 0;
    }
