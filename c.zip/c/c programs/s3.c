#include<stdio.h>
#include<conio.h>
void swap(int x,int y)
{
    int temp;
    temp=x;
    x=y;
    y=temp;
}
int main()
{
    int a ,b;
    printf("Enter the values:");
    scanf("%d %d",&a,&b);

    printf("\n before swap a : %d|b : %d ",a,b);
     swap(a,b);
     printf("\n after swap a : %d|b : %d ",a,b);
     return 0;
     }
