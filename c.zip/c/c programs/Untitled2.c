#include<stdio.h>
    void myfun(char name[])
    {
    printf(" HELLO %s",name);
    printf ("\n enter name: %s",);
    scanf("%s",name);
    }
    int main()
    {
    myfun(name);

    return 0;
    }
