#include<stdio.h>
#include<math.h>

int main()
{

    printf("\nSQRT  : %0.2f",sqrt(4));
    printf("\nPOW   : %0.2f",pow(2,3));
    printf("\nabs   : %d",abs(-25));
    printf("\nCEIL  : %f",ceil(3.8));
    printf("\nCEIL  : %f",ceil(3.2));
    printf("\nFLOOR : %f",floor(3.8));
    printf("\nFLOOR : %f",floor(3.2));
    printf("\nROUND : %f",round(3.8));
    printf("\nROUND : %f",round(3.2));
    return 0;
}
