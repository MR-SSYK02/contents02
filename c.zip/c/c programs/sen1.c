#include<stdio.h>
int main(){
FILE*fp;
char c[10];
fp=fopen("dynamic.txt","r");
c=getc(fp);
printf("%c",c);
return 0;
}
