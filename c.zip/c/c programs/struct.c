#include<stdio.h>
#include<string.h>
    struct book{
    int no;
    float price;
    char author[40];
    };
int main()
{
    struct book hp;
    hp.no=5;
    hp.price=52.02;
    strcpy(hp.author,"abc");
    printf("%d\n",hp.no);
    printf("%f\n",hp.price);
    printf("%s\n",hp.author);
    return 0;
}
