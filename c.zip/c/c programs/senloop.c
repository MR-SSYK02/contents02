#include<stdio.h>
int main(){
int num,sum=1;
while(1){
printf("Enter the number= ");
scanf("%d",&num);
if(num==0){
 break;
 }else{
   sum=num+sum;
   }
   }
   printf("sum of all postive number=%d",sum);
   return 0;
}
