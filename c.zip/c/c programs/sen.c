#include<stdio.h>
#include<conio.h>
int main(){
 int num;
 printf("/n Enter the num: ");
 scanf("%d",&num);
 return 0;
}
