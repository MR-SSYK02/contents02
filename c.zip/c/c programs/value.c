#include<stdio.h>
void swap(int x,int y)
{
    int temp=x;
    x=y;
    y=temp;
}
int main()
{
    int x,y;
    printf("\Enter your number:");
    scanf("%d%d",&x,&y);
    printf("original %d|%d");
    swap(&x,&y);
    printf("after swap %d|%d");
    return 0;

}
