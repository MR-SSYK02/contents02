#include<stdio.h>
#include<math.h>
int main()
{
    printf("abs :%d", abs(-26));
    return 0;
}
