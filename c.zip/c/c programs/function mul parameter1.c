#include <stdio.h>

void myFunction(char name[], int age) {
  printf("Hello %s You are %d years old\n", name, age);
}

int main() {
  myFunction("senthil", 20);
  myFunction("Jenny", 14);
  myFunction("Anja", 30);
  return 0;
}
