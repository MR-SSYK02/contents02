#include<stdio.h>
int add();
int main(){
    int a;
    a=add();
    printf("\nTotal:%d",a);
    return 0;
}
int add()
{
        int a,b;
        printf("\nEnter your value;");
        scanf("%d%d",&a,&b);
        return a+b;
}
