#include <stdio.h>
#include <conio.h>
int main()
{
    int num1,num2, sum;
    printf("\nEnter two integers :");
    scanf("%d %d",&num1,&num2);
    sum = num1 + num2;
    printf("%d + %d =%d",num1,num2,sum);
    return 0;
}
