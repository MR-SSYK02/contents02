#include<stdio.h>
int main()
{
    int num;
    printf("Enter your number :");
    scanf("%d",&num)
    return 0;

}
