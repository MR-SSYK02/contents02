#include<stdio.h>
    void myfun()
    {
    printf("hello");
    }
    int main()
    {
    myfun();
    return 0;
    }
