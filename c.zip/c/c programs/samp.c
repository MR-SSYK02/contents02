#include<stdio.h>
#include<math.h>
int main()
{
    printf("\n SQRT :%f",sqrt(20));
    printf("\n POW :%f",pow(15,20));
    printf("\n CELL :%f",ceil(1.5));
    printf("\n abs :%f",abs(12.65));
    printf("\n FLOOR :%f",floor(1.2));
    printf("\n ROUND :%f",round(2.05));
    return 0;

    }
