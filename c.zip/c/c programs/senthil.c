#include<stdio.h>
    void senthil()
    {
    printf("hello");
    }
    int main()
    {
    senthil();
    return 0;
    }
