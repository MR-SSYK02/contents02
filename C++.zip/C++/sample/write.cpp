#include<iostream>
#include<fstream>
using namespace std;
int main()
{
    ofstream o("test.txt",ios::app);
    o<<"hello"<<endl;
    o<<"how are you"<<endl;
    o.close();
    return 0;
}
