#include<iostream>
#include<fstream>
using namespace std;
int main()
{
    string mytext;
    ifstream myreadfile("test.txt");
    while(getline(myreadfile,mytext))
    {
        cout<<mytext<<endl;
    }
    myreadfile.close();
  return 0;
}
