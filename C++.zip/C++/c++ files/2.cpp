#include<iostream>
using namespace std;
int main()
{
    int a,b;
    cout<<"enter your number : ";
    cin>>a>>b;
    if(a>b);
    {
        cout<<"enter your number : ";
        cin>>a>>b;
        if(a<b);

    }
    return 0;
}
