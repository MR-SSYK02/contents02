#include<iostream>
#include<fstream>
using namespace std;
int main()
{
    ofstream o("test.txt",ios::app);
    return 0;
}
