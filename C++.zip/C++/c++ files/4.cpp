#include<iostream>
using namespace std;

namespace name1{
string name="ram";
int age=52;
}
int main()
{
    cout<<name1::name;
    cout<<name1::age;
    return 0;

}
