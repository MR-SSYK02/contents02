
#include<iostream>
using namespace std;
int main()
{
    string a;
    cout<<"Enter para:";
    getline(cin,a);
    cout<<"value:"<<a;
    return 0;
}
