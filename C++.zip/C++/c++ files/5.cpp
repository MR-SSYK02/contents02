#include<iostream>
using namespace std;

namespace name1{
string name="ram";
int age=52;
}
namespace name2{
string name="ram";
int age=5;
}
using namespace name2;
int main()
{
    cout<<name;
    cout<<age;
    return 0;

}
