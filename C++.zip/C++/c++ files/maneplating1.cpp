#include<iostream>
using namespace std;
int main()
{
    string b;
    cout<<"enter the string :";
    cin>>b;
    cout<<"size :"<<b.size();
    return 0;
}
