#include<iostream>
using namespace std;
int main()
{
    string a;
    cout<<"enter the string:";
    cin>>a;
    string::iterator it;
    for(it=str.begin();it!=str.end();it++)
    return 0;
}
