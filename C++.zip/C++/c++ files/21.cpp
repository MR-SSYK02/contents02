#include<iostream>
using namespace std;
int main()
{
    char a[]={1,2,3,4,5};
    for(char x :a)
    {
        cout<<x<<endl;
    }
    return 0;
}
