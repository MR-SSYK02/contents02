var letter = "a"
if(letter=="a" ||letter=="e" || letter=="i" ||letter=="o" || letter=="u")
{
    console.log("its an vowel")
}
else{
    console.log("it not an vowel")
}